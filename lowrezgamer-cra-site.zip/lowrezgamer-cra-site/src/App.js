import React from "react";
import "./App.css";

function App() {
  return (
    <div className="App">
      <header>
        <h1>Welcome to LowRezGamer</h1>
        <p>A visually impaired content creator and streamer</p>
      </header>

      <section aria-label="Bio">
        <h2>About Me</h2>
        <p>I’m LowRezGamer — a visually impaired gamer and streamer creating content for everyone, especially the low vision community.</p>
      </section>

      <section aria-label="Social Media Links">
        <h2>Social Media</h2>
        <ul>
          <li><a href="#" target="_blank" rel="noopener noreferrer">Twitch</a></li>
          <li><a href="#" target="_blank" rel="noopener noreferrer">YouTube</a></li>
          <li><a href="#" target="_blank" rel="noopener noreferrer">Twitter/X</a></li>
        </ul>
      </section>

      <section aria-label="Game Clips and VODs">
        <h2>Game Clips / VODs</h2>
        <p>Upload or embed your best gameplay moments here!</p>
      </section>

      <section aria-label="Help and Advice">
        <h2>Community Help & Advice</h2>
        <p>A space for others with visual impairments to reach out, share tips, or ask for help.</p>
      </section>
    </div>
  );
}

export default App;
