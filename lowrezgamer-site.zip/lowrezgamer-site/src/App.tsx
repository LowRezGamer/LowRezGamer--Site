import React from "react";
import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Textarea } from "./components/ui/textarea";
import { Switch } from "./components/ui/switch";

export default function App() {
  return (
    <div className="bg-black text-red-500 min-h-screen p-4 space-y-8">
      <header className="text-center text-4xl font-bold">LowRezGamer</header>

      <section aria-labelledby="bio" className="space-y-2">
        <h2 id="bio" className="text-2xl font-semibold">About Me</h2>
        <Card>
          <CardContent>
            <p>
              I'm LowRezGamer, a visually impaired content creator and streamer.
              I play games, stream on Twitch, and aim to build a helpful
              community for visually impaired gamers.
            </p>
          </CardContent>
        </Card>
      </section>

      <section aria-labelledby="socials" className="space-y-2">
        <h2 id="socials" className="text-2xl font-semibold">Follow Me</h2>
        <Card>
          <CardContent className="space-y-2">
            <ul className="list-disc list-inside">
              <li><a href="#" className="underline">Twitch</a></li>
              <li><a href="#" className="underline">YouTube</a></li>
              <li><a href="#" className="underline">Twitter/X</a></li>
              <li><a href="#" className="underline">Instagram</a></li>
            </ul>
          </CardContent>
        </Card>
      </section>

      <section aria-labelledby="vods" className="space-y-2">
        <h2 id="vods" className="text-2xl font-semibold">Game Clips / Twitch VODs</h2>
        <Card>
          <CardContent className="space-y-4">
            <p>Embed or link your favorite Twitch clips or uploads here:</p>
            <iframe
              title="Twitch Player"
              src="https://player.twitch.tv/?channel=yourchannel&parent=yourdomain.com"
              height="300"
              width="100%"
              allowFullScreen
            ></iframe>
          </CardContent>
        </Card>
      </section>

      <section aria-labelledby="community" className="space-y-2">
        <h2 id="community" className="text-2xl font-semibold">Ask for Help or Advice</h2>
        <Card>
          <CardContent>
            <form className="space-y-4">
              <Input type="text" placeholder="Your name (optional)" />
              <Textarea placeholder="What do you need help with?" />
              <Button type="submit">Submit Request</Button>
            </form>
          </CardContent>
        </Card>
      </section>

      <section aria-labelledby="accessibility" className="space-y-2">
        <h2 id="accessibility" className="text-2xl font-semibold">Accessibility Settings</h2>
        <Card>
          <CardContent className="flex items-center space-x-4">
            <label htmlFor="high-contrast">High Contrast Mode</label>
            <Switch id="high-contrast" />
          </CardContent>
        </Card>
      </section>

      <section aria-labelledby="subscribe" className="space-y-2">
        <h2 id="subscribe" className="text-2xl font-semibold">Stay Updated</h2>
        <Card>
          <CardContent>
            <form className="space-y-2">
              <Input type="email" placeholder="Your email address" />
              <Button type="submit">Subscribe</Button>
            </form>
          </CardContent>
        </Card>
      </section>

      <section aria-labelledby="testimonials" className="space-y-2">
        <h2 id="testimonials" className="text-2xl font-semibold">Community Voices</h2>
        <Card>
          <CardContent>
            <blockquote>
              "Thanks to LowRezGamer's advice, I was able to start streaming as a
              blind gamer!" — Community Member
            </blockquote>
          </CardContent>
        </Card>
      </section>

      <section aria-labelledby="blog" className="space-y-2">
        <h2 id="blog" className="text-2xl font-semibold">Blog & Tips</h2>
        <Card>
          <CardContent>
            <ul className="list-disc list-inside">
              <li><a href="#" className="underline">Top 5 Games with Accessibility Features</a></li>
              <li><a href="#" className="underline">How I Setup My Stream as a Low Vision Gamer</a></li>
            </ul>
          </CardContent>
        </Card>
      </section>

      <footer className="text-center pt-8 text-sm text-gray-400">
        &copy; 2025 LowRezGamer. All rights reserved.
      </footer>
    </div>
  );
}
