export const Card = ({ children }) => <div className='rounded-2xl bg-zinc-900 shadow p-4'>{children}</div>;
export const CardContent = ({ children }) => <div>{children}</div>;