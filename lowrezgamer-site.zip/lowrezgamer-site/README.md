# LowRezGamer Website

This is the official website for **LowRezGamer**, a visually impaired content creator and streamer.

### Features:
- Black and red high-contrast theme
- Screen reader friendly
- Social media links
- Twitch VODs and game clips
- Community help & advice section
- Accessibility settings

### Follow me:
- Twitch: [Your Link]
- YouTube: [Your Link]
- Twitter/X: [Your Link]

Built to support and empower the low-vision gamer community.
